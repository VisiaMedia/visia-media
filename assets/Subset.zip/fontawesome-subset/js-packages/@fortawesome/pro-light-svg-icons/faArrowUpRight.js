'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-right';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e09f';
var svgPathData = 'M320 111.9v223.3c0 8.844-7.156 16-16 16s-16-7.156-16-16V150.6l-260.7 260.7C24.19 414.4 20.09 416 16 416s-8.188-1.562-11.31-4.688c-6.25-6.25-6.25-16.38 0-22.62l260.9-260.9l-185.6-.5547C71.11 127.2 63.97 120 64 111.2c.0313-8.844 7.188-15.97 16-15.97l224 .6562C312.9 95.94 320 103.1 320 111.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;