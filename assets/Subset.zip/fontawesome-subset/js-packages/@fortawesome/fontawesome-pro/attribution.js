console.log(`Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license (Commercial License)
Copyright 2023 Fonticons, Inc.
`)