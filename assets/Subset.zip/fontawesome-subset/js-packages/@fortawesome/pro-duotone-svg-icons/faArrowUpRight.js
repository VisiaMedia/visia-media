'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-up-right';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e09f';
var svgPathData = ['M256 205.3l-201.4 201.4C48.38 412.9 40.19 416 32 416s-16.38-3.125-22.62-9.375c-12.5-12.5-12.5-32.75 0-45.25L210.8 160H256V205.3z', 'M288 384c-17.67 0-32-14.31-32-32V160H64C46.33 160 32 145.7 32 128s14.33-32 32-32h224c17.67 0 32 14.31 32 32v224C320 369.7 305.7 384 288 384z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;