export const faLinkedinIn: IconDefinition;
export const faFacebookF: IconDefinition;
export const faInstagram: IconDefinition;
import { IconDefinition, IconLookup, IconName, IconPrefix, IconPack } from '@fortawesome/fontawesome-common-types';
export { IconDefinition, IconLookup, IconName, IconPrefix, IconPack } from '@fortawesome/fontawesome-common-types';
export const prefix: IconPrefix;
export const fab: IconPack;